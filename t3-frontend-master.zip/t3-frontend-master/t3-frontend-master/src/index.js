angular
  .module('app', ['ui.router', 'core.service', 'core.sdk', 'core.directive']);
