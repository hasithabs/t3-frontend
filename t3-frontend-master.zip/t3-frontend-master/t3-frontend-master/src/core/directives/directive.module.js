angular.module('core.directive', []);
