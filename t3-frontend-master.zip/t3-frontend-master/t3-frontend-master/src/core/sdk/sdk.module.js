angular
  .module('core.sdk', ['core.service', 'core.common']);
