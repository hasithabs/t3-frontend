angular.module('core.service', ['core.common', 'ngResource']);
