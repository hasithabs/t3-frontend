angular
  .module('core.common', [])
  .constant('SETTINGS', {
    // App common settings goes here
  });
