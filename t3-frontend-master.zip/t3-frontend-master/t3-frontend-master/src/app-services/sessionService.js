// 'use strict';
//
// angular.module('app').factory('sessionService', ['$http', function($http) {
//
//     return {
//         set: function (key, value) {
//             sessionStorage.setItem(key, value);
//         },
//
//         get: function()
//         {
//             return sessionStorage.getItem(key);
//         },
//
//         destory: function()
//         {
//             return sessionStorage.removeItem(key);
//         }
//     }
//
// }]);